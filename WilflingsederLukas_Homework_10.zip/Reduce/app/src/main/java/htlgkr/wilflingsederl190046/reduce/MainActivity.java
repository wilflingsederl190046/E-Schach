package htlgkr.wilflingsederl190046.reduce;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ParseException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        EditText etZaehler = findViewById(R.id.zaehler);
        EditText etNenner = findViewById(R.id.nenner);
        int zaehler;
        int nenner;
        if(!etZaehler.getText().toString().equals("") && !etNenner.getText().toString().equals("")) {

            zaehler = Integer.parseInt(etZaehler.getText().toString());
            nenner = Integer.parseInt(etNenner.getText().toString());

            if (zaehler != 0 && nenner != 0) {
                int largerNumber;
                int smallerNumber;
                if (zaehler > nenner) {
                    largerNumber = zaehler;
                    smallerNumber = nenner;
                } else {
                    largerNumber = nenner;
                    smallerNumber = zaehler;
                }

                int rest = largerNumber % smallerNumber;

                while (rest != 0) {
                    largerNumber = smallerNumber;
                    smallerNumber = rest;
                    rest = largerNumber % smallerNumber;
                }

                zaehler = zaehler / smallerNumber;
                nenner = nenner / smallerNumber;

                etZaehler.setText(Integer.toString(zaehler));
                etNenner.setText(Integer.toString(nenner));
            } else {
                etZaehler.setText("");
                etNenner.setText("");
                new IllegalArgumentException("The numbers cannot be zero").printStackTrace();
            }
        } else {
            etZaehler.setText("");
            etNenner.setText("");
            new IllegalArgumentException("Please enter a number in both field!").printStackTrace();
        }
    }
}