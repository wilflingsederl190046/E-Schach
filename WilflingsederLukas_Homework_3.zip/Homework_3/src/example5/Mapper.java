package example5;

import java.util.ArrayList;
import java.util.List;

public interface Mapper<S, T> {

    T map(S s);

    default List<T> mapAll(List<S> l) {
        List<T> list = new ArrayList<>();
        for(S s : l) {
            list.add(map(s));
        }
        return list;
    }
}
