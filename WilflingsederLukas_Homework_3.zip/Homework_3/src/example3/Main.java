package example3;

import java.util.Scanner;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Main {
    final static Predicate<Integer> isEven = number -> number % 2 == 0;
    final static Predicate<Integer> isPositive = number -> number >= 0;
    final static IntPredicate isZero = number -> number == 0;
    final static Predicate<Integer> isNull = number -> number == null;

    final static Predicate<String> isShortWord = string -> string.toCharArray().length < 4;

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Zahl eingeben:");
        int number = s.nextInt();
        System.out.println("Zahl ist gerade: " + isEven.test(number) + "\n" +
                "Zahl ist positiv: " + isPositive.test(number) + "\n" +
                "Zahl ist Null: " + isZero.test(number) + "\n" +
                "Wert ist null: " + isNull.test(number) + "\n");

        System.out.println("Wort eingeben:");
        String word = s.next();
        System.out.println("Wort kürzer als 4 Buchstaben: " + isShortWord.test(word) + "\n");

        System.out.println("Zahl ist positiv und gerade: " + (isPositive.and(isEven)).test(number) + "\n" +
                "Zahl ist positiv und ungerade: " + (isPositive.and(isEven.negate())).test(number));
    }
}
