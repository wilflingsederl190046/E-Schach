package example1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {
        /*Task 1.1*/
        List<Weapon> weaponList = new ArrayList<>();

        try (final BufferedReader br = new BufferedReader(new FileReader("weapons.csv"))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                String name = parts[0];
                CombatType combatType = null;
                CombatType[] ctValues = CombatType.values();
                for (int i = 0; i < ctValues.length; i++) {
                    if (parts[1].equals(ctValues[i].toString())) {
                        combatType = ctValues[i];
                        break;
                    }
                }

                DamageType damageType = null;
                DamageType[] dtValues = DamageType.values();
                for (int i = 0; i < dtValues.length; i++) {
                    if (parts[2].equals(dtValues[i].toString())) {
                        damageType = dtValues[i];
                        break;
                    }
                }

                int damage = Integer.parseInt(parts[3]);
                int speed = Integer.parseInt(parts[4]);
                int strength = Integer.parseInt(parts[5]);
                int value = Integer.parseInt(parts[6]);
                Weapon weapon = new Weapon(name, combatType, damageType, damage, speed, strength, value);
                weaponList.add(weapon);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        /* Task 1.5 */
        Printable p1 = (weapons) -> weapons.forEach((weapon) -> System.out.println(weapon + "\n"));

        Weapon w = new Weapon();

        /*w.sortWeaponListByDamage(weaponList);
        System.out.println("Sorted by damage:\n");
        p1.print(weaponList);*/

        /*w.sortWeaponListByCompatTypeDamageTypeName(weaponList);
        System.out.println("Sorted by combatType, damageType and name:\n");
        p1.print(weaponList);*/

        System.out.println("Please enter 1 to sort by damage and 2 to sort by combatType, damageType and name");
        Scanner scanner = new Scanner(System.in);
        int userInput = scanner.nextInt();
        if(userInput == 1) {
            w.sortWeaponListByDamage(weaponList);
        } else if(userInput == 2) {
            w.sortWeaponListByCompatTypeDamageTypeName(weaponList);
        } else {
            throw new IllegalArgumentException("Please only enter 1 or 2!");
        }

        /* Task 1.6 */
        Printable p2 = (weapons) -> {
            System.out.println(String.format("%-18s|", "name") + String.format("%-10s|", "combatType") + String.format("%-10s|", "damageType") + String.format("%-6s|", "damage") + String.format("%-5s|", "speed") + String.format("%-8s|", "strength") + String.format("%-5s", "value") + "\n" +
                    "------------------+----------+----------+------+-----+--------+-----");

            for(int i = 0; i < weapons.size(); i++) {
                String name = String.format("%-18s|", weapons.get(i).getName());
                String combatType = String.format("%-10s|", weapons.get(i).getCombatTyp());
                String damageType = String.format("%-10s|", weapons.get(i).getDamageTyp());
                String damage = String.format("%-6s|", weapons.get(i).getDamage());
                String speed = String.format("%-5s|", weapons.get(i).getSpeed());
                String strength = String.format("%-8s|", weapons.get(i).getStrength());
                String value = String.format("%-5s", weapons.get(i).getValue());
                System.out.println(name + combatType + damageType + damage + speed + strength + value);
            }
        };
        System.out.println("List in table (sorted):");
        p2.print(weaponList);

        weaponList.clear();

        /* Task 1.7 */
        weaponList = Files.lines(new File("weapons.csv").toPath())
                .skip(1)
                .map(s -> s.split(";"))
                .map(s -> new Weapon(
                        s[0],
                        CombatType.valueOf(s[1]),
                        DamageType.valueOf(s[2]),
                        Integer.parseInt(s[3]),
                        Integer.parseInt(s[4]),
                        Integer.parseInt(s[5]),
                        Integer.parseInt(s[6])
                ))
                .collect(Collectors.toList());

        System.out.println("\nList read in with one stream (unsorted):");
        p2.print(weaponList);
    }
}