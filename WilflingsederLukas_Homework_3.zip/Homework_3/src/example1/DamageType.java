package example1;

public enum DamageType {
    SLASHING,
    MISSILE,
    BLUNT,
    PIERCING,
    NONE
}
