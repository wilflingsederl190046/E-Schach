package example1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Weapon {

    private String name;
    private CombatType combatTyp;
    private DamageType damageTyp;
    private int damage;
    private int speed;
    private int strength;
    private int value;

    public Weapon() {
    }

    public Weapon(String name, CombatType combatTyp, DamageType damageTyp, int damage, int speed, int strength, int value) {
        this.name = name;
        this.combatTyp = combatTyp;
        this.damageTyp = damageTyp;
        this.damage = damage;
        this.speed = speed;
        this.strength = strength;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public CombatType getCombatTyp() {
        return combatTyp;
    }

    public DamageType getDamageTyp() {
        return damageTyp;
    }

    public int getDamage() {
        return damage;
    }

    public int getSpeed() {
        return speed;
    }

    public int getStrength() {
        return strength;
    }

    public int getValue() {
        return value;
    }

    /*Task 1.2: sorted with damage in descending order.*/
    public List<Weapon> sortWeaponListByDamage(List<Weapon> weaponList) {
        weaponList.sort((Weapon w1, Weapon w2) -> w2.getDamage() - w1.getDamage());
        return weaponList;
    }

    /*Task 1.3: sorted with combatType, damageType and name.*/
    public List<Weapon> sortWeaponListByCompatTypeDamageTypeName(List<Weapon> weaponList) {
        weaponList.sort((Weapon w1, Weapon w2) -> {
            if (w1.getCombatTyp() != w2.getCombatTyp()) {
                return w1.getCombatTyp().toString().compareTo(w2.getCombatTyp().toString());
            } else if (w1.getDamageTyp() != w2.getDamageTyp()) {
                return w1.getDamageTyp().toString().compareTo(w2.getDamageTyp().toString());
            }
            return w1.getName().compareTo(w2.getName());
        });
        return weaponList;
    }

    @Override
    public String toString() {
        return name + ":\n" +
                "   -combat type: " + combatTyp.toString() + "  -damage type: " + damageTyp.toString() + "\n" +
                "   -damage: " + damage + "   -speed: " + speed + "   -strength: " + strength + "   -value: " + value;
    }
}
