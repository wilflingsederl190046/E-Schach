package example1;

public enum CombatType {
    MELEE,
    RANGED,
    NONE
}
