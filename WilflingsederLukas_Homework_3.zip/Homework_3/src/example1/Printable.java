package example1;

import java.util.List;

/*Task 1.4*/
public interface Printable {
    void print(List<Weapon> weapons);
}
