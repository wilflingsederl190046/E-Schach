package example4;

import java.util.stream.IntStream;

public class Main {
    final static int result = IntStream.of(1,2,3,4,5,6,7,8,9,10)
            .filter(value -> value % 2 == 1)
            .map(value -> value * value)
            .reduce(0, (a, b) -> a + b);

    public static void main(String[] args) {
        System.out.println(result);
    }
}
