package net.htlgrieskirchen.pos3.streams;

public enum DamageType {
    SLASHING, PIERCING, BLUNT, MISSILE, NONE
}
