package net.htlgrieskirchen.pos3.streams;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Streams {

    public double average(int[] numbers) {
        int allNumbers = Arrays.stream(numbers).reduce(0, (n1, n2) -> n1 + n2);
        return  (double) allNumbers / numbers.length;
    }
    
    public List<String> upperCase(String[] strings) {
        List<String> stringList = Arrays.asList(strings);
        return stringList.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
    }
    
    public Weapon findWeaponWithLowestDamage(List<Weapon> weapons) {
        Optional<Weapon> weapon = weapons.stream().reduce((w1, w2) -> w1.getDamage() < w2.getDamage() ? w1 : w2);
        if(!weapons.isEmpty()) {
            return weapon.get();
        }
        return null;
    }
    
    public Weapon findWeaponWithHighestStrength(List<Weapon> weapons) {
        Optional<Weapon> weapon = weapons.stream().reduce((w1, w2) -> w1.getMinStrength() > w2.getMinStrength() ? w1 : w2);
        if(!weapons.isEmpty()) {
            return weapon.get();
        }
        return null;
    }
    
    public List<Weapon> collectMissileWeapons(List<Weapon> weapons) {
        Stream<Weapon> list = weapons.stream().filter(weapon -> weapon.getDamageType().equals(DamageType.MISSILE));
        return list.collect(Collectors.toList());
    }
    
    public Weapon findWeaponWithLongestName(List<Weapon> weapons) {
        Optional<Weapon> weapon = weapons.stream().reduce((w1, w2) -> w1.getName().toCharArray().length > w2.getName().toCharArray().length ? w1 : w2);
        if(!weapons.isEmpty()) {
            return weapon.get();
        }
        return null;
    }
    
    public List<String> toNameList(List<Weapon> weapons) {
        Stream<String> list = weapons.stream().map(weapon -> weapon.getName());
        return list.collect(Collectors.toList());
    }
    
    public int[] toSpeedArray(List<Weapon> weapons) {
        return weapons.stream().mapToInt(weapon -> weapon.getSpeed()).toArray();
    }
    
    public int sumUpValues(List<Weapon> weapons) {
        return weapons.stream().mapToInt(w -> w.getValue()).reduce(0, (w1, w2) -> w1 + w2);
    }
    
    public long sumUpHashCodes(List<Weapon> weapons) {
        return weapons.stream().mapToLong(Weapon::hashCode).reduce(0, (w1, w2) -> w1 + w2);
    }
    
    public List<Weapon> removeDuplicates(List<Weapon> weapons) {
        return weapons.stream().distinct().collect(Collectors.toList());
    }
    
    public void increaseValuesByTenPercent(List<Weapon> weapons) {
        int[] allValues = weapons.stream().mapToInt(w -> (w.getValue() + (w.getValue() / 10))).toArray();
        for(int i = 0; i < allValues.length; i++) {
            weapons.get(i).setValue(allValues[i]);
        }
    }
}
