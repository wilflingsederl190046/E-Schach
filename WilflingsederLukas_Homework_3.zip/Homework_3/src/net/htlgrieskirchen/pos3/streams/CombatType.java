package net.htlgrieskirchen.pos3.streams;

public enum CombatType {
    MELEE, RANGED, NONE
}
