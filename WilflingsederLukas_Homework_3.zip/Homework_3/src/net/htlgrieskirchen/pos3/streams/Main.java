package net.htlgrieskirchen.pos3.streams;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        /* Task 2.1 */
        int[] randomNumbers = new int[10000];
        for (int i = 0; i < randomNumbers.length; i++) {
            randomNumbers[i] = (int) ( Math.random() * 100) + 0;
        }

        Streams s = new Streams();
        System.out.println(s.average(randomNumbers));

        String[] randomStrings = new String[10];
        String letters = "abcdefghijklmnopqrstuvxyz";
        char[] randomLetters = letters.toCharArray();
        for(int i = 0; i < randomStrings.length; i++) {
            String random = "";
            for(int y = 0; y < 10; y++)  {
                random += randomLetters[(int) (Math.random() * 10) + 0];
            }
            randomStrings[i] = random;
        }

        List<String> stringList = s.upperCase(randomStrings);
        for(String st : stringList) {
            System.out.println(st);
        }
    }
}
