package example1;

import junit.framework.TestCase;
import org.junit.Before;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class WeaponTest extends TestCase {

    private List<Weapon> weaponList;

    @Before
    public void setUp() throws IOException {
        weaponList = new ArrayList<>();

        try (final BufferedReader br = new BufferedReader(new FileReader("weapons.csv"))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                String name = parts[0];
                CombatType combatType = null;
                CombatType[] ctValues = CombatType.values();
                for (int i = 0; i < ctValues.length; i++) {
                    if (parts[1].equals(ctValues[i].toString())) {
                        combatType = ctValues[i];
                        break;
                    }
                }

                DamageType damageType = null;
                DamageType[] dtValues = DamageType.values();
                for (int i = 0; i < dtValues.length; i++) {
                    if (parts[2].equals(dtValues[i].toString())) {
                        damageType = dtValues[i];
                        break;
                    }
                }

                int damage = Integer.parseInt(parts[3]);
                int speed = Integer.parseInt(parts[4]);
                int strength = Integer.parseInt(parts[5]);
                int value = Integer.parseInt(parts[6]);
                Weapon weapon = new Weapon(name, combatType, damageType, damage, speed, strength, value);
                weaponList.add(weapon);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void testSortWeaponListByDamage() {
        Weapon w = new Weapon();
        List<Weapon> expResult = weaponList;
        List<Weapon> result = w.sortWeaponListByDamage(weaponList);
        Collections.sort(expResult, new Comparator<Weapon>() {
            @Override
            public int compare(Weapon w1, Weapon w2) {
                return w2.getDamage() - w1.getDamage();
            }
        });
        assertEquals(result, expResult);
    }

    public void testSortWeaponListByCompatTypeDamageTypeName() {
        Weapon w = new Weapon();
        List<Weapon> expResult = weaponList;
        List<Weapon> result = w.sortWeaponListByCompatTypeDamageTypeName(weaponList);
        Collections.sort(expResult, new Comparator<Weapon>() {
            @Override
            public int compare(Weapon w1, Weapon w2) {
                if (w1.getCombatTyp() != w2.getCombatTyp()) {
                    return w1.getCombatTyp().toString().compareTo(w2.getCombatTyp().toString());
                } else if (w1.getDamageTyp() != w2.getDamageTyp()) {
                    return w1.getDamageTyp().toString().compareTo(w2.getDamageTyp().toString());
                }
                return w1.getName().compareTo(w2.getName());
            }
        });
        assertEquals(result, expResult);
    }
}