package net.htlgrieskirchen.pos3.timeutil;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Main {
    public static void main(String[] args) {
        /*Date date = new Date(2003 - 1900, Calendar.FEBRUARY, 1);
        System.out.println(date);
        Calendar calendar = new GregorianCalendar(2003,1,1);
        System.out.println(calendar.getTime());
        Date date = new Date(2003 - 1900, Calendar.FEBRUARY, 1);
        System.out.println(date.getTime());
        LocalDateTime l = LocalDateTime.of(2003, 12, 2, 12, 34);
        System.out.println(l.toString());*/
        LocalDate l2 = LocalDate.of(2003, 12, 2);
        System.out.println(l2);
    }
}
