package com.example.project_echess;

public class MenueFXMLController {
}
