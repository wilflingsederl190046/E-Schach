package demo.rsickinger;

public interface Printable {

    void print(Weapon weapon);

}