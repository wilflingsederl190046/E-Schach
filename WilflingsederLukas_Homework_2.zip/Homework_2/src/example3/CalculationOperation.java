package example3;

public interface CalculationOperation {
    Number calc(Number x, Number y);
}
