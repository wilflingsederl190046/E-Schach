package com.example.project_echess;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class ChessClient extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Menu.fxml"));
        Parent root= fxmlLoader.load();
        MenuController controller_1 = (MenuController) fxmlLoader.getController();

        controller_1.setPrimaryStage(stage);
        Scene scene = new Scene(root);
        stage.setTitle("E-Chess");
        stage.setScene(scene);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                System.exit(0);
            }
        });
        stage.show();
    }

    public static void main(String[] args) {
        Socket socket = null;
        try {
            socket = new Socket("localhost", 4711);

            launch();

            OutputStream out = socket.getOutputStream();
            PrintStream ps = new PrintStream(out, true);

            InputStream in = socket.getInputStream();
            BufferedReader buff = new BufferedReader(new InputStreamReader(in));

            while (true) {
                String line = buff.readLine();
                if(line.equals("menue_launch")) {

                } else if(line.startsWith("menue_data;")) {

                }
            }

        } catch (UnknownHostException e) {
            System.out.println("Unknown Host...");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IOProblems...");
            e.printStackTrace();
        } finally {
            if (socket != null)
                try {
                    socket.close();
                    System.out.println("Socket closed...");
                } catch (IOException e) {
                    System.out.println("Socket cannot get closed...");
                    e.printStackTrace();
                }
        }
    }
}
