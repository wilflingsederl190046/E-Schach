package com.example.project_echess;

public class Rook extends LinearChessman {

    public Rook(boolean isBlack) {
        super(isBlack,'R',true,false,Integer.MAX_VALUE);
    }
}
