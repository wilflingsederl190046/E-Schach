package com.example.project_echess;

public class King extends LinearChessman {

    public King(boolean isColorBlack) {
        super(isColorBlack, 'K', true, true, 1);
    }
}
