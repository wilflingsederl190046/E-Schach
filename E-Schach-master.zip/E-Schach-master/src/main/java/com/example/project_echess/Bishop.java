package com.example.project_echess;

public class Bishop extends LinearChessman {

    public Bishop(boolean isBlack) {
        super(isBlack,'B',false,true,Integer.MAX_VALUE);
    }


}
