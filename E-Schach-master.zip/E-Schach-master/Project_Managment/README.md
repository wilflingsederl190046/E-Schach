# Schachspiel
Das Schach Projekt von Gruppe E.

## Anforderungen
Programmiersprache: java

Zwei Spieler sollen auf zwei verschiedenen Endgeräten gegeneinander Schach spielen können.

## UI
Das Menü sieht so aus:

Das Programm sieht wiefolgt aus:
![image](https://user-images.githubusercontent.com/91054413/151655637-dd45183b-d81e-44b2-9631-e91fab75ce06.png)

## Verbindung
Dieses Programm startet mit einem Menü, indem man sich dann mit einem zweiten Spieler über Sockets verbinden kann und somit gegeneindander Schach kann.

## Regeln
Die Regeln sind die Regeln von Schach.

## Ende des Spiels
Das Spiel is vorbei, wenn eine der Spieler seinen König verliert.

## Zeiteinteilung
https://docs.google.com/spreadsheets/d/1UnxE3jU4z1MMn8Kzz_JcdcX9pQwGRV2zX-LpgJYb1lU/edit?usp=sharing
