package htlgkr.wilflingsederl190046.reduce;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText etZaehler;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);
        etZaehler = findViewById(R.id.zaehler);
        tvResult = findViewById(R.id.result);
    }

    @Override
    public void onClick(View view) {
        String formula = etZaehler.getText().toString().trim();
        RecursiveCalculator rc = new RecursiveCalculator();

        int result = rc.calculate(formula);
        tvResult.setText(Integer.toString(result));
    }

    private static class RecursiveCalculator {
        private int counter = 0;

        public int calculate(String s) {
            return expression(s);
        }

        // ausdruck = term, [ "+" | "-" , term ];
        private int expression(String s) {
            int left = term(s);

            while(true) {
                Part operation = Part(s);
                if (operation.partType == TYPE.PLUS || operation.partType == TYPE.MINUS) {
                    counter++;
                    switch (operation.partType) {
                        case PLUS:
                            left += term(s);
                            break;
                        case MINUS:
                            left -= term(s);
                            break;
                    }
                } else {
                    return left;
                }
            }
        }

        //term = " (" , ausdruck , " )"
        //| "0" | "1" | . . . | "9" ;
        private int term(String s) {
            int value = 0;
            Part part = Part(s);

            switch(part.partType) {
                case NUMBER:
                    value = part.partValue;
                    break;
                case LEFTBRACKET:
                    counter++;
                    value = expression(s);
                    counter++;
                    break;
            }

            return value;
        }

        //alle Stellen vom String kategorisieren mit extra Klasse "Part"
        private Part Part(String s) {
            while(counter < s.length() && Character.isWhitespace(s.charAt(counter))) {
                counter++;
            }

            if(counter < s.length() && Character.isDigit(s.charAt(counter))) {
                int number = Character.getNumericValue(s.charAt(counter));
                counter++;
                return new Part(TYPE.NUMBER, number);
            } else if(counter < s.length()) {
                switch(s.charAt(counter)) {
                    case '+':
                        return new Part(TYPE.PLUS, 0);
                    case '-':
                        return new Part(TYPE.MINUS, 0);
                    case '(':
                        return new Part(TYPE.LEFTBRACKET, 0);
                    case ')':
                        return new Part(TYPE.RIGHTBRACKET, 0);
                }
            }
            return new Part(TYPE.NUMBER, 0);
        }

        enum TYPE {
            NUMBER,
            PLUS,
            MINUS,
            LEFTBRACKET,
            RIGHTBRACKET
        }

        class Part {
            public TYPE partType;
            public int partValue;

            public Part(TYPE PartType, int PartValue) {
                this.partType = PartType;
                this.partValue = PartValue;
            }
        }
    }
}

